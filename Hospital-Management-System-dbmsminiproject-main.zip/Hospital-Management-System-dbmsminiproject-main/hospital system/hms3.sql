-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2021 at 11:52 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: hms
--

-- --------------------------------------------------------

--
-- Table structure for table doctors
--

CREATE TABLE doctors (
  did int(11) NOT NULL AUTO_INCREMENT,
  email varchar(50) NOT NULL,
  doctorname varchar(50) NOT NULL,
  dept varchar(100) NOT NULL,
  PRIMARY KEY (did)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table doctors
--

INSERT INTO doctors (did, email, doctorname, dept) VALUES
(1, 'anees@gmail.com', 'anees', 'Cardiologists'),
(2, 'amrutha@gmail.com', 'amrutha bhatta', 'Dermatologists');

-- --------------------------------------------------------

--
-- Table structure for table patients
--

CREATE TABLE patients (
  pid int(11) NOT NULL AUTO_INCREMENT,
  email varchar(50) NOT NULL,
  name varchar(50) NOT NULL,
  gender varchar(50) NOT NULL,
  slot varchar(50) NOT NULL,
  disease varchar(50) NOT NULL,
  time time NOT NULL,
  date date NOT NULL,
  dept varchar(50) NOT NULL,
  number varchar(12) NOT NULL,
  PRIMARY KEY (pid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table patients
--

INSERT INTO patients (pid, email, name, gender, slot, disease, time, date, dept, number) VALUES
(2, 'anees1@gmail.com', 'anees1 rehman khan', 'Male1', 'evening1', 'cold1', '21:20:00', '2020-02-02', 'ortho11predict', '9874561110'),
(5, 'patient@gmail.com', 'patien', 'Male', 'morning', 'fevr', '18:06:00', '2020-11-18', 'Cardiologists', '9874563210');

-- --------------------------------------------------------

--
-- Table structure for table test
--

CREATE TABLE test (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(20) NOT NULL,
  email varchar(20) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table test
--

INSERT INTO test (id, name, email) VALUES
(1, 'ANEES', 'ARK@GMAIL.COM'),
(2, 'test', 'test@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table trigr
--

CREATE TABLE trigr (
  tid int(11) NOT NULL AUTO_INCREMENT,
  pid int(11) NOT NULL,
  email varchar(50) NOT NULL,
  name varchar(50) NOT NULL,
  action varchar(50) NOT NULL,
  timestamp datetime NOT NULL,
  PRIMARY KEY (tid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table trigr
--

INSERT INTO trigr (tid, pid, email, name, action, timestamp) VALUES
(1, 12, 'anees@gmail.com', 'ANEES', 'PATIENT INSERTED', '2020-12-02 16:35:10'),
(2, 11, 'anees@gmail.com', 'anees', 'PATIENT INSERTED', '2020-12-02 16:37:34'),
(3, 10, 'anees@gmail.com', 'anees', 'PATIENT UPDATED', '2020-12-02 16:38:27'),
(4, 11, 'anees@gmail.com', 'anees', 'PATIENT UPDATED', '2020-12-02 16:38:33'),
(5, 12, 'anees@gmail.com', 'ANEES', 'Patient Deleted', '2020-12-02 16:40:40'),
(6, 11, 'anees@gmail.com', 'anees', 'PATIENT DELETED', '2020-12-02 16:41:10'),
(7, 13, 'testing@gmail.com', 'testing', 'PATIENT INSERTED', '2020-12-02 16:50:21'),
(8, 13, 'testing@gmail.com', 'testing', 'PATIENT UPDATED', '2020-12-02 16:50:32'),
(9, 13, 'testing@gmail.com', 'testing', 'PATIENT DELETED', '2020-12-02 16:50:57'),
(10, 14, 'aneeqah@gmail.com', 'aneeqah', 'PATIENT INSERTED', '2021-01-22 15:18:09'),
(11, 14, 'aneeqah@gmail.com', 'aneeqah', 'PATIENT UPDATED', '2021-01-22 15:18:29'),
(12, 14, 'aneeqah@gmail.com', 'aneeqah', 'PATIENT DELETED', '2021-01-22 15:41:48'),
(13, 15, 'khushi@gmail.com', 'khushi', 'PATIENT INSERTED', '2021-01-22 15:43:02'),
(14, 15, 'khushi@gmail.com', 'khushi', 'PATIENT UPDATED', '2021-01-22 15:43:11'),
(15, 16, 'khushi@gmail.com', 'khushi', 'PATIENT INSERTED', '2021-01-22 15:43:37'),
(16, 16, 'khushi@gmail.com', 'khushi', 'PATIENT UPDATED', '2021-01-22 15:43:49'),
(17, 17, 'aneeqah@gmail.com', 'aneeqah', 'PATIENT INSERTED', '2021-01-22 15:44:41'),
(18, 17, 'aneeqah@gmail.com', 'aneeqah', 'PATIENT UPDATED', '2021-01-22 15:44:52'),
(19, 17, 'aneeqah@gmail.com', 'aneeqah', 'PATIENT UPDATED', '2021-01-22 15:44:59');

-- --------------------------------------------------------

--
-- Table structure for table user
--

CREATE TABLE user (
  id int(11) NOT NULL AUTO_INCREMENT,
  username varchar(50) NOT NULL,
  usertype varchar(50) NOT NULL,
  email varchar(50) NOT NULL,
  password varchar(1000) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table user
--

INSERT INTO user (id, username, usertype, email, password) VALUES
(13, 'anees', 'Doctor', 'anees@gmail.com', 'pbkdf2:sha256:150000$xAKZCiJG$4c7a7e704708f86659d730565ff92e8327b01be5c49a6b1ef8afdf1c531fa5c3'),
(14, 'aneeqah', 'Patient', 'aneeqah@gmail.com', 'pbkdf2:sha256:150000$Yf51ilDC$028cff81a536ed9d477f9e45efcd9e53a9717d0ab5171d75334c397716d581b8'),
(15, 'khushi', 'Patient', 'khushi@gmail.com', 'pbkdf2:sha256:150000$BeSHeRKV$a8b27379ce9b2499d4caef21d9d387260b3e4ba9f7311168b6e180a00db91f22');

-- --------------------------------------------------------

--
-- Table structure for table login
--

CREATE TABLE login (
  sid int(11) NOT NULL AUTO_INCREMENT,
  email varchar(50) NOT NULL,
  password varchar(50) NOT NULL,
  PRIMARY KEY (sid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table login
--

INSERT INTO login (sid, email, password) VALUES
(1, 'newuser1@gmail.com', 'New User 1'),
(2, 'newuser2@gmail.com', 'New User 2');

-- --------------------------------------------------------

--
-- Triggers for patients
--
DELIMITER $$
CREATE TRIGGER PatientDelete BEFORE DELETE ON patients FOR EACH ROW 
INSERT INTO trigr VALUES(null, OLD.pid, OLD.email, OLD.name, 'PATIENT DELETED', NOW())
$$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER PatientUpdate AFTER UPDATE ON patients FOR EACH ROW 
INSERT INTO trigr VALUES(null, NEW.pid, NEW.email, NEW.name, 'PATIENT UPDATED', NOW())
$$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER patientinsertion AFTER INSERT ON patients FOR EACH ROW 
INSERT INTO trigr VALUES(null, NEW.pid, NEW.email, NEW.name, 'PATIENT INSERTED', NOW())
$$
DELIMITER ;

--
-- Triggers for login
--
DELIMITER $$
CREATE TRIGGER LoginInsert AFTER INSERT ON login FOR EACH ROW 
INSERT INTO trigr VALUES(null, NEW.sid, NEW.email, NEW.password, 'LOGIN', NOW())
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

-- No need for additional indexes, all primary keys and unique constraints are already set during table creation.

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;